import json
from datetime import datetime
from pathlib import Path
from google import genai
from google.genai import types
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render,redirect
from django.core.exceptions import PermissionDenied
from django.views.decorators.csrf import csrf_exempt
from .models import Submission,Post,Reply,UserProfile,ShopItem,UserItem
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib.auth.views import LoginView,PasswordResetView
from django import forms
from django.contrib.auth.models import User
from django.contrib import messages

import pybryt
import pybryt.student as _student
from pybryt.preprocessors import NotebookPreprocessor
from pybryt.utils import make_secret
import nbformat as _nbformat
import os as _os, dill as _dill
from copy import deepcopy as _deepcopy
from tempfile import mkstemp as _mkstemp
from textwrap import dedent as _dedent
from nbconvert.preprocessors import ExecutePreprocessor as _EP
from textwrap import indent


client = genai.Client(api_key=settings.GEMINI_API_KEY)


EDITABLE_STUDENT_FILE_TYPES = {".ipynb", ".py", ".txt", ".json", ".md"}
EVALUATABLE_STUDENT_FILE_TYPES = {".ipynb"}
PYBRYT_EXECUTION_TIMEOUT_SECONDS = 20

LEVELS = [
    {
        "id": "chapter-1-level-1",
        "chapter": "第 1 章第一關",
        "level": "1-1",
        "title": "變數港口",
        "difficulty": "20％",
        "story_url": "https://ypvisblity.github.io/chapter_python/ch_1/index.html",
        "game_url": "http://127.0.0.1:8888/notebooks/chapter-1-level-1.ipynb",
        "summary": "1-1描述",
        "warn":"返回題目點選按鈕，進入關卡",
        "topics": [
        {
            "id": "chapter-1-level-1-1",
            "title": "認識變數",
            "description":"蘋果的價格為26元，請問小明購買6個蘋果需要多少錢?\t請用value(x,y)計算蘋果總價為何?",
            "starter_code": "# 在這裡寫程式\n",
            "test_code": "value(26,6)",
        },
        {
            "id":"chapter-1-level-1-2",
            "title":"解釋變數",
            "description":"設定a為一頭牛，b為吃了一顆草?\t請輸出a+b的結果",
            "starter_code":"#請在這裡寫程式\n",
            "test_code":"value(a,b)",
        },
        ]
    },
    {
        "id": "chapter-1-level-2",
        "chapter": "第 1 章第二關",
        "level": "1-2",
        "title": "if else判斷",
        "difficulty": "20％",
        "story_url": "http://127.0.0.1:8080/renpy/chapter-1-level-2/",
        "game_url": "http://127.0.0.1:8888/notebooks/chapter-1-level-2.ipynb", 
        "summary": "1-2描述",
        "warn":"返回題目點選按鈕，進入關卡",
        "topics": [
        {
            "id": "chapter-1-level-2-1",
            "title": "BMI計算",
            "description": "請定義一個basic(height, weight) 函數，計算BMI判斷過輕、正常、過重。bmi< 18.5為過輕、18.5<=bmi<=24為正常、bmi > 24為過重",
            "starter_code": "# 在這裡寫程式\n",
            "test_code": "print(basic(1.78, 70))\nprint(basic(1.60, 40))\nprint(basic(1.60, 80))",
        },
        ]
    },
    {
        "id": "chapter-1-level-3",
        "chapter": "第 1 章第三關",
        "level": "1-3",
        "title": "矩陣相加",
        "difficulty": "20％",
        "story_url": "http://127.0.0.1:8080/renpy/chapter-1-level-3/",
        "game_url": "http://127.0.0.1:8888/notebooks/chapter-1-level-3.ipynb",
        "summary": "1-3描述",
        "warn":"返回題目點選按鈕，進入關卡",
        "topics": [
        {
            "id": "chapter-1-level-3-1",
            "title": "矩陣相加",
            "description": "請定義一個matrix_add(A,B)函數，計算函數相加。使用for迴圈",
            "starter_code": "# 在這裡寫程式\n",
            "test_code": "A = [[1,2],[3,4]]\nB = [[5,6],[7,8]]\nmatrix_add(A,B)\nA = [[2,1],[0,3]]\nB = [[1,4],[5,2]]\nmatrix_add(A,B)",
        },
        ]
    },
    {
        "id": "chapter-2-level-1",
        "chapter": "第 2 章第一關",
        "level": "2-1",
        "title": "等差數列",
        "difficulty": "40％",
        "story_url": "http://127.0.0.1:8080/renpy/chapter-2-level-1/",
        "game_url": "http://127.0.0.1:8888/notebooks/chapter-2-level-1.ipynb",
        "summary": "2-1描述",
        "warn":"返回題目點選按鈕，進入關卡",
        "topics": [
        {
            "id": "chapter-2-level-1-1",
            "title": "等差數列",
            "description": "請建立一個sequence串列後使用公式term = a + i * d計算等差數列。",
            "starter_code": "# 在這裡寫程式\n",
            "test_code": "val = generate_arithmetic_sequence(2,3,5)\nval",
        },
        ]
    },
    {
        "id": "chapter-2-level-2",
        "chapter": "第 2 章第二關",
        "level": "2-2",
        "title": "檔案與例外處理",
        "difficulty": "40％",
        "story_url": "http://127.0.0.1:8080/renpy/chapter-2-level-2/",
        "game_url": "http://127.0.0.1:8888/notebooks/chapter-2-level-2.ipynb",
        "summary": "2-2描述",
        "warn":"返回題目點選按鈕，進入關卡",
        "topics": [
        {
            "id": "chapter-2-level-2-1",
            "title": "try-catch兩數相除",
            "description": "請使用try/except處理除以零的錯誤\n，請定義safe_divide(a,b)，當b=0時回傳Error:除以零，否則ab相除回傳結果",
            "starter_code": "# 在這裡寫程式\n",
            "test_code": "print(safe_divide(10,0))\nprint(safe_divide(10,2))\n",
        },
        ]
    },
    {
        "id": "chapter-2-level-3",
        "chapter": "第 2 章第三關",
        "level": "2-3",
        "title": "守衛問答",
        "difficulty": "40％",
        "story_url": "http://127.0.0.1:8080/renpy/chapter-2-level-3/",
        "game_url": "http://127.0.0.1:8888/notebooks/chapter-2-level-3.ipynb",
        "summary": "2-3描述",
        "warn":"返回題目點選按鈕，進入關卡",
    },
    {
        "id": "chapter-3-level-1",
        "chapter": "第 3 章第一關",
        "level": "3-1",
        "title": "迴圈礦坑",
        "difficulty": "60％",
        "story_url": "http://127.0.0.1:8080/renpy/chapter-3-level-1/",
        "game_url": "http://127.0.0.1:8888/notebooks/chapter-3-level-1.ipynb",
        "summary": "3-1描述",
        "warn":"返回題目點選按鈕，進入關卡",
    },
    {
        "id": "chapter-3-level-2",
        "chapter": "第 3 章第二關",
        "level": "3-2",
        "title": "函式工坊",
        "difficulty": "60％",
        "story_url": "http://127.0.0.1:8080/renpy/chapter-3-level-2/",
        "game_url": "http://127.0.0.1:8888/notebooks/chapter-3-level-2.ipynb",
        "summary": "3-2描述",
    },
    {
        "id": "chapter-3-level-3",
        "chapter": "第 3 章第三關",
        "level": "3-3",
        "title": "資料結構",
        "difficulty": "80％",
        "story_url": "http://127.0.0.1:8080/renpy/chapter-3-level-3/",
        "game_url": "http://127.0.0.1:8888/notebooks/chapter-3-level-3.ipynb",
        "summary": "3-3描述",
        "warn":"返回題目點選按鈕，進入關卡",
        "topics": [
        {
            "id": "chapter-3-level-3-1",
            "title": "陣列與串列",
            "description":"""...""",
            "starter_code": "# 在這裡寫程式\n,",
            "test_code": """sll = SinglyLinkedList()
sll.append(10)
sll.append(20)
sll.append(30)
assert sll.to_list() == [10, 20, 30], "append 或 to_list 尚未正確完成"

sll.insert_at(1, 15)
assert sll.to_list() == [10, 15, 20, 30], "insert_at 尚未正確完成"

sll.delete_by_value(15)
assert sll.to_list() == [10, 20, 30], "delete_by_value 尚未正確完成"

print("恭喜！基礎任務全部通過，可以繼續挑戰進階任務。")"""
        },
        {
            "id": "chapter-3-level-3-2",
            "title": "認識變數",
            "description":"蘋果的價格為26元，請問小明購買6個蘋果需要多少錢?\t請用value(x,y)計算蘋果總價為何?",
            "starter_code": "# 在這裡寫程式\n",
            "test_code": "value(26,6)",
        },
        {
            "id": "chapter-3-level-3-3",
            "title": "認識變數",
            "description":"蘋果的價格為26元，請問小明購買6個蘋果需要多少錢?\t請用value(x,y)計算蘋果總價為何?",
            "starter_code": "# 在這裡寫程式\n",
            "test_code": "value(26,6)",
        },
        {
            "id": "chapter-3-level-3-4",
            "title": "認識變數",
            "description":"蘋果的價格為26元，請問小明購買6個蘋果需要多少錢?\t請用value(x,y)計算蘋果總價為何?",
            "starter_code": "# 在這裡寫程式\n",
            "test_code": "va"
            "lue(26,6)",
        },
        ]
    },
]


def home(request):
    levels_by_id = {level["id"]: level for level in LEVELS}
    user_points = 0 
    shop_items=ShopItem.objects.filter(is_active=True)
    owned_item_ids = set()
    profile=None
    if request.user.is_authenticated:
        user_points = (
            UserProfile.objects.filter(user=request.user)
            .values_list("points", flat=True)
            .first()
            or 0
        )
        profile,created=UserProfile.objects.get_or_create(user=request.user)
        owned_item_ids=set(
            UserItem.objects.filter(user=request.user)
            .values_list("item_id",flat=True)
        )

    return render(request,"pages/home.html",{
            "levels": LEVELS,
            "levels_json": json.dumps(levels_by_id, ensure_ascii=False),
            "user_name": request.user.username if request.user.is_authenticated else "Guest",
            "user_points": user_points,
            "shop_items":shop_items,
            "owned_item_ids":owned_item_ids,
            "profile":profile,
        },)



def get_posts(request):
    level_id = request.GET.get("level_id", "")
    posts = Post.objects.filter(level_id=level_id).prefetch_related("replies", "likes")
    data = []
    for post in posts:
        data.append({
            "id": post.id,
            "author": post.author.username,
            "content": post.content,
            "created_at": post.created_at.strftime("%Y/%m/%d %H:%M"),
            "likes": post.likes.count(),
            "liked": request.user in post.likes.all() if request.user.is_authenticated else False,
            "replies": [
                {
                    "id": r.id,
                    "author": r.author.username,
                    "content": r.content,
                    "created_at": r.created_at.strftime("%Y/%m/%d %H:%M"),
                }
                for r in post.replies.all()
            ]
        })
    return JsonResponse({"posts": data})

@csrf_exempt
@login_required
def create_post(request):
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed"}, status=405)
    data = json.loads(request.body)
    level_id = data.get("level_id", "")
    content = data.get("content", "").strip()
    if not content:
        return JsonResponse({"error": "內容不能為空"}, status=400)
    post = Post.objects.create(author=request.user, level_id=level_id, content=content)
    return JsonResponse({
        "id": post.id,
        "author": post.author.username,
        "content": post.content,
        "created_at": post.created_at.strftime("%Y/%m/%d %H:%M"),
        "likes": 0,
        "liked": False,
        "replies": []
    })

@login_required
def toggle_like(request, post_id):
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed"}, status=405)
    try:
        post = Post.objects.get(id=post_id)
    except Post.DoesNotExist:
        return JsonResponse({"error": "找不到文章"}, status=404)
    if request.user in post.likes.all():
        post.likes.remove(request.user)
        liked = False
    else:
        post.likes.add(request.user)
        liked = True
    return JsonResponse({"likes": post.likes.count(), "liked": liked})

@login_required
def create_reply(request, post_id):
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed"}, status=405)
    try:
        post = Post.objects.get(id=post_id)
    except Post.DoesNotExist:
        return JsonResponse({"error": "找不到文章"}, status=404)
    data = json.loads(request.body)
    content = data.get("content", "").strip()
    if not content:
        return JsonResponse({"error": "回覆不能為空"}, status=400)
    reply = Reply.objects.create(post=post, author=request.user, content=content)
    return JsonResponse({
        "id": reply.id,
        "author": reply.author.username,
        "content": reply.content,
        "created_at": reply.created_at.strftime("%Y/%m/%d %H:%M"),
    })

@login_required
def my_submissions(request):
    submissions = Submission.objects.filter(user=request.user)
    return render(request, "pages/submissions.html", {
        "submissions": submissions
    })

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True, label="Email")

    class Meta:
        model = User
        fields = ["email","username","password1","password2"]

class CustomPasswordResetView(PasswordResetView):
    template_name = "registration/password_reset.html"
    
    def form_valid(self, form):
        email = form.cleaned_data.get("email")
        # 檢查資料庫是否有此email
        if not User.objects.filter(email=email).exists():
            messages.error(self.request, "此 Email 尚未註冊帳號，請確認後再試。")
            return self.form_invalid(form)
        return super().form_valid(form)

def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("/")
    else:
        form = RegisterForm()
    return render(request, "registration/register.html", {"form": form})

def _teacher_required(user):
    return (
        user.is_authenticated
        and (
            user.is_staff
            or user.is_superuser
            or user.groups.filter(name="Teachers").exists()
        )
    )

class RoleLoginView(LoginView):
    template_name = "registration/login.html"

    def _is_teacher_login(self):
        return self.request.POST.get("next") == "/teacher/files/" or self.request.GET.get("next") == "/teacher/files/"

    def form_valid(self, form):
        user = form.get_user()
        is_teacher = _teacher_required(user)

        if self._is_teacher_login() and not is_teacher:
            form.add_error(None, "學生帳號不能從老師登入入口登入。")
            return self.form_invalid(form)

        if not self._is_teacher_login() and is_teacher:
            form.add_error(None, "老師帳號請使用老師登入入口。")
            return self.form_invalid(form)

        return super().form_valid(form)

def _student_files_dir():
    submissions_dir = Path(settings.BASE_DIR) / "submissions"
    submissions_dir.mkdir(exist_ok=True)
    return submissions_dir

def _safe_student_file(filename):
    submissions_dir = _student_files_dir().resolve()
    file_path = (submissions_dir / filename).resolve()
    if submissions_dir not in file_path.parents or file_path.suffix not in EDITABLE_STUDENT_FILE_TYPES:
        raise PermissionDenied
    return file_path

def _infer_level_from_filename(filename):
    parts = filename.split("_", 2)
    if len(parts) >= 2:
        return parts[1]
    return "unknown-level"

def _parent_level_for_topic(level):
    for chapter in LEVELS:
        topic_ids = [
            topic["id"]
            for topic in chapter.get("topics", [])
            if topic.get("id")
        ]
        if level in topic_ids:
            return chapter["id"]
    return None


def _find_reference_file(level):
    references_dir = Path(settings.BASE_DIR) / "references"
    candidate_levels = [level]

    parent_level = _parent_level_for_topic(level)
    if parent_level and parent_level not in candidate_levels:
        candidate_levels.append(parent_level)

    if not level.endswith("-1"):
        candidate_levels.append(f"{level}-1")

    for candidate_level in candidate_levels:
        ref_path = references_dir / f"{candidate_level}.pkl"
        if ref_path.exists():
            return ref_path, candidate_level
    return None, candidate_levels[-1]

def _patch_pybryt_execute_notebook():
    def _patched_execute_notebook(nb, nb_path, addl_filenames=[], timeout=PYBRYT_EXECUTION_TIMEOUT_SECONDS):
        nb = _deepcopy(nb)
        preprocessor = NotebookPreprocessor()
        nb = preprocessor.preprocess(nb)

        fd, footprint_fp = _mkstemp()
        _os.close(fd)
        safe_fp = footprint_fp.replace("\\", "/")

        nb_dir = _os.path.abspath(_os.path.split(nb_path)[0])
        secret = make_secret()
        ftv = f"frame_tracer_{secret}"

        first_cell = _nbformat.v4.new_code_cell(_dedent(f"""
            import inspect, sys
            from pybryt.execution import FrameTracer
            {ftv} = FrameTracer(inspect.currentframe())
            {ftv}.start_trace(addl_filenames={addl_filenames})
            %cd {nb_dir}
        """))

        last_cell = _nbformat.v4.new_code_cell(_dedent(f"""
            {ftv}.end_trace()
            footprint = {ftv}.get_footprint()
            footprint.filter_out_unpickleable_values()
            import dill
            with open("{safe_fp}", "wb+") as f:
                dill.dump(footprint, f)
        """))

        nb["cells"].insert(0, first_cell)
        nb["cells"].append(last_cell)
        _EP(timeout=timeout, allow_errors=True).preprocess(nb)

        with open(footprint_fp, "rb") as f:
            footprint = _dill.load(f)
        _os.remove(footprint_fp)
        footprint.add_imports(*preprocessor.get_imports())
        footprint.set_executed_notebook(nb)
        return footprint

    _student.execute_notebook = _patched_execute_notebook

def evaluate_student_file(file_path, level=None):
    level = level or _infer_level_from_filename(file_path.name)
    if file_path.suffix not in EVALUATABLE_STUDENT_FILE_TYPES:
        return {
            "filename": file_path.name,
            "level": level,
            "passed": None,
            "steps": None,
            "messages": "此檔案類型不能使用 PyBryt 評測。",
            "feedback": [],
        }

    _patch_pybryt_execute_notebook()
    ref_path, reference_level = _find_reference_file(level)
    if ref_path is None:
        return {
            "filename": file_path.name,
            "level": level,
            "passed": None,
            "steps": None,
            "messages": f"找不到 {level} 或 {reference_level} 的參考答案。",
            "feedback": [],
        }

    reference = pybryt.ReferenceImplementation.load(str(ref_path))
    student_impl = pybryt.StudentImplementation(str(file_path))
    results = student_impl.check(reference)
    result_list = results if isinstance(results, list) else [results]
    first_result = result_list[0]

    feedback = []
    all_passed = True
    for result in result_list:
        if not result.correct:
            all_passed = False
        for ann_res in result.to_dict()["results"]:
            ann = ann_res["annotation"]
            satisfied = ann_res["satisfied"]
            feedback.append({
                "name": ann.get("name", "檢查點"),
                "passed": satisfied,
                "message": ann.get("success_message") if satisfied else ann.get("failure_message"),
            })

    return {
        "filename": file_path.name,
        "level": reference_level,
        "passed": all_passed,
        "steps": student_impl.footprint.num_steps,
        "messages": "\n".join(first_result.messages),
        "feedback": feedback,
    }
#老師查看檔案畫面
@login_required
def teacher_files(request):
    if not _teacher_required(request.user):
        raise PermissionDenied

    submissions_dir = _student_files_dir()

    files = [
        {
            "name": path.name,
            "size": path.stat().st_size,
            "modified_at": datetime.fromtimestamp(path.stat().st_mtime),
            "can_review": path.suffix in EVALUATABLE_STUDENT_FILE_TYPES,
        }
        for path in submissions_dir.iterdir()
        if path.is_file() and path.suffix in EDITABLE_STUDENT_FILE_TYPES
    ]
    files.sort(key=lambda item: item["modified_at"], reverse=True)
    return render(request, "teacher/files.html", {
        "files": files,
        "review_results": [],
    })
#老師審查、評測檔案
@login_required
def teacher_review_one_file(request, filename):
    if not _teacher_required(request.user):
        raise PermissionDenied

    file_path = _safe_student_file(filename)
    if not file_path.exists() or not file_path.is_file():
        raise PermissionDenied

    try:
        result = evaluate_student_file(file_path)
    except Exception as e:
        result = {
            "filename": file_path.name,
            "level": _infer_level_from_filename(file_path.name),
            "passed": False,
            "steps": None,
            "messages": f"評測錯誤：{str(e)}",
            "feedback": [],
        }

    return JsonResponse(result)

@login_required
def teacher_file_edit(request, filename):
    if not _teacher_required(request.user):
        raise PermissionDenied

    file_path = _safe_student_file(filename)
    if not file_path.exists() or not file_path.is_file():
        raise PermissionDenied

    message = ""
    review_result = None
    if request.method == "POST":
        try:
            review_result = evaluate_student_file(file_path)
            message = "已完成 PyBryt 評測。"
        except Exception as e:
            review_result = {
                "filename": file_path.name,
                "level": _infer_level_from_filename(file_path.name),
                "passed": False,
                "steps": None,
                "messages": f"評測錯誤：{str(e)}",
                "feedback": [],
            }
            message = "PyBryt 評測失敗。"

    content = file_path.read_text(encoding="utf-8")
    return render(
        request,
        "teacher/file_edit.html",
        {
            "filename": file_path.name,
            "content": content,
            "message": message,
            "review_result": review_result,
        },
    )

#商店購買
@login_required
def shop(request,item_id):
    if request.method != "POST":
        return JsonResponse({"error":"不允許"},status=405)
    profile, created = UserProfile.objects.get_or_create(user=request.user)

    try:
        item = ShopItem.objects.get(id=item_id,is_active=True)
    except ShopItem.DoesNotExist:
        return JsonResponse({"error":"找不到商品"},status=404)
    if UserItem.objects.filter(user=request.user,item=item).exists():
        return JsonResponse({"error":"你已經購買這件物品"},status=400)
    if profile.points < item.price:
        return JsonResponse({"error":"你沒有可以支付這件物品的費用"},status=400)
    profile.points -=item.price
    profile.save()

    UserItem.objects.create(user=request.user,item=item)

    return JsonResponse({
        "message":"購買成功",
        "points":profile.points,
        "item":{
            "id":item.id,
            "name":item.name,
            "price":item.price,
        }
    })



def ai_chat(request):
    if request.method =="POST":
        try:
            data = json.loads(request.body)
            user_message = data.get("message", "")
            if not user_message:
                return JsonResponse({"error":"輸入內容不能為空"},status=400)
            #google search tools
            #極度消耗token,所以先暫停
            #tools= [types.Tool(googleSearch=types.GoogleSearch()),]
            # 思考程度與關卡指定 （模型配置）
            generate_content_config = types.GenerateContentConfig(
                #tools=tools 購買額度再去使用 先設定成None
                tools=None,
                system_instruction=[
                    types.Part.from_text(text="""只利用到 python 的技巧以及導入numpy 等等套件 
        https://steam.oxxostudio.tw/category/python/info/start.html
        參考這份steam教育學習網站的python 技巧
        只回答python的問題，其他一律回答這不符合我們的關卡內容。
        若是他詢問Lv1-1-1的問題則回答
        def value(x,y):
            if x == 0 or y == 0:
                return "EOFError"
            else:
                return x*y
        並且說明為何要這麼做題目為蘋果價格與數量計算
        若是詢問lv1-2-1的問題則回答
        def basic(h,w):
            bmi= w/(h*h)
            if (bmi < 18.5):
                return "過輕"
            elif (bmi > 24):
                return "過重"
            else:
                return "正常"
        並且說明為何要這麼做題目為bmi測量
        若是詢問lv1-3-1的問題則會回答
        使用一個for迴圈來表示row的值再在裡面套個for迴圈表示col的值，像是這樣:
        def matrix_add(A,B):
        ...
        ...
        for i in range(row):
            row = []
            for i in range(col):
                ...
        若是詢問lv2-1-1的問題則回答
        def sequence(a,d,n):
        ...
        ...
        for i in range(n):
                term = a + i * d
            sequence.append(term)"""),
                ],
            )
            try:
                #1.優先嘗試呼叫最新的3.5模型
                response = client.models.generate_content(
                    model="gemini-3.5-flash",
                    contents=[user_message],
                    config=generate_content_config,
                )
            except Exception as model_err:
                # 2. 如果遇到503錯誤不論是透過 code 屬性還是字串比對），觸發降級機制
                err_msg = str(model_err)
                err_code = getattr(model_err, 'code', None) 
                if err_code == 503 or "503" in err_msg or "Service Unavailable" in err_msg:
                    # 降級改用容量較大、穩定的2.5模型
                    response = client.models.generate_content(
                        model="gemini-2.5-flash",
                        contents=[user_message],
                        config=generate_content_config,
                    )
                else:
                    # 如果不是503，就把原本的錯誤往外丟給外層 catch 處理
                    raise model_err
            
            return JsonResponse({"reply": response.text})
        
        except json.JSONDecodeError:
            return JsonResponse({"error":"無效的 JSON 格式"},status=400)
        
        except Exception as e:
            if "503" in str(e):
               return JsonResponse({"error":"模型忙碌中，請稍後再試。"},status=500)
            else:
                raise
            # return JsonResponse({"error":f"系統錯誤: {str(e)}"},status=500)    
            
    return render(request,'ai/ai_chat.html')
    
@csrf_exempt
def submit_solution(request):
    if request.method != "POST":
        return JsonResponse({"message": "Only POST requests are accepted."}, status=405)

    raw_level = request.POST.get("level", "unknown-level").replace("/", "-").replace("\\", "-")
    level = raw_level
    player = request.POST.get("player", "player").replace("/", "-").replace("\\", "-")
    notebook_json = request.POST.get("notebook", "").strip()

    if not notebook_json:
        return JsonResponse({"message": "請先輸入要提交的程式碼。"}, status=400)

    try:
        notebook_data = json.loads(notebook_json)
    except json.JSONDecodeError:
        return JsonResponse({"message": "Notebook 格式錯誤。"}, status=400)

    submitted_at = datetime.now().strftime("%Y%m%d-%H%M%S")
    submissions_dir = Path(settings.BASE_DIR) / "submissions"
    submissions_dir.mkdir(exist_ok=True)
    filename = f"{submitted_at}_{level}_{player}.ipynb"
    file_path = submissions_dir / filename
    file_path.write_text(
        json.dumps(notebook_data, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )
    try:
        review_result = evaluate_student_file(file_path, level)
        all_passed = review_result["passed"]
        reward_points = 0
        total_points = None

        if request.user.is_authenticated:
            profile, created = UserProfile.objects.get_or_create(user=request.user)
            already_passed = Submission.objects.filter(
                user=request.user,
                level=level,
                passed=True,
            ).exists()

            if all_passed and not already_passed:
                reward_points = 10
                profile.points += reward_points
                profile.save()

            total_points = profile.points
            Submission.objects.create(
                user=request.user,
                level=level,
                filename=filename,
                passed=all_passed,
            )
        

        return JsonResponse({
            "message": "全部通過！" if all_passed else "部分未通過",
            "filename": filename,
            "passed": all_passed,
            "reward_points": reward_points,
            "total_points": total_points,
            "steps": review_result["steps"],
            "messages": review_result["messages"],
            "feedback": review_result["feedback"],
        })

    except Exception as e:
        return JsonResponse({
            "message": f"已儲存 {filename}，鑑定錯誤：{str(e)}",
            "filename": filename,
            "passed": False,
            "feedback": []
        })
